
   exports.get_landing = (req, res, next) => {
    res.render('landing', { title: 'Express from Theodore with Controllers' });
   }
   exports.submit_lead = function(req, res, next) {
      console.log("lead_name:", req.body.lead_name);
      console.log("lead_email:", req.body.lead_email);
      res.redirect('/');
     }
     